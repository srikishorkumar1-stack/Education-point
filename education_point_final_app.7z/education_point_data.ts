// Education Point data export
export const EDUCATION_POINT = {
  "Math": {
    "shortNotes": [
      {
        "id": 1,
        "chapter": "Chapter 1 - Real Numbers",
        "notes": "Key formulas and summary."
      }
    ],
    "detailedSolutions": [
      {
        "chapter": "Chapter 1 - Real Numbers",
        "questions": [
          {
            "id": 1,
            "question": "Question 1",
            "solution": "Sample step-by-step solution."
          }
        ]
      }
    ]
  },
  "Science": {
    "shortNotes": [
      {
        "id": 1,
        "chapter": "Chemical Reactions",
        "notes": "Important points"
      }
    ],
    "detailedSolutions": [
      {
        "chapter": "Chemical Reactions",
        "questions": [
          {
            "id": 1,
            "question": "Q1",
            "solution": "Answer"
          }
        ]
      }
    ]
  },
  "SocialScience": {
    "shortNotes": [],
    "detailedSolutions": []
  },
  "Hindi": {
    "shortNotes": [],
    "detailedSolutions": []
  },
  "English": {
    "shortNotes": [],
    "detailedSolutions": []
  },
  "Sanskrit": {
    "shortNotes": [],
    "detailedSolutions": []
  }
};
